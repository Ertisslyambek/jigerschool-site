<?php
// Данные для подключения к базе
$host = "localhost";
$dbname = "p-339575_contact_db"; // Имя базы данных
$username = "p-339575_contact_user"; // Имя пользователя
$password = "%ug6I909j"; // Пароль от базы данных

try {
    // Подключение к базе данных
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Проверяем, пришли ли данные из формы
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = htmlspecialchars($_POST["name"]);
        $email = htmlspecialchars($_POST["email"]);
        $message = htmlspecialchars($_POST["message"]);

        // Запрос на добавление данных в таблицу
        $sql = "INSERT INTO messages (name, email, message) VALUES (:name, :email, :message)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(["name" => $name, "email" => $email, "message" => $message]);

        // После успешной отправки перенаправляем обратно на страницу с формой
        header("Location: index.html?success=1");
        exit();
    }
} catch (PDOException $e) {
    echo "Ошибка: " . $e->getMessage();
}
?>
